<?php

return [
    'consult_our_doctors' => 'Consult Our Doctors',
    'results' => "some results",
    'yes_for_yessmile' => 'yes for good smile <b>yes smile</b>',
];
