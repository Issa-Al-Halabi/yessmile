<?php

return [
    'our_branches' => 'Our Branches',
    'all_our_branches' => 'All our branches around the world',
];
