<?php

return [
    'Home' => 'Home',
    'ourClinic' => 'our clinic',
    'aboutus' => 'about us',
    'ourteam' => 'our team',
    'our_world' => 'our World',
    'our_branches' => 'our Branches',
    'languages' => 'languages',
    'arabic' => 'arabic',
    'english' => 'English',
    'free_consultation' => 'free Consultation',
    'our_serices' => 'our Serices',
    'book_now' => 'book now',
    'follow_us_on_social_media' => 'follow us on social media',
    'contact_us' => 'contact us',
    'privacy_policy' => 'privacy policy',
    'terms' => 'conditions & terms',

];
