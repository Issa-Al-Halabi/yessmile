<?php

return [
    'no_title_yet' => 'No title yet',
    'no_description_yet' => 'No description yet',
    'our_doctors' => 'Our doctors',
    'specialist' => 'specialist:',
    'book_a_consultation_with' => 'Book a consultation with',
];
