<?php

return [
    'articles' => 'Articles',
    'categories' => 'Categories',
    'all' => 'All',
    'continue' => 'Continue',
    'last_news' => 'Last News',
];
