<?php

return [
    'who_are_we' => 'who are we',
    'put_a_smile' => 'We are here to put a smile back on your faces',
    'no_title_yet' => 'No title yet',
    'no_description_yet' => 'No description yet',
    'consult_our_doctors_for_free' => 'Consult our doctors for free',
    'book_your_appointment_now' => 'Book your appointment now',
    'why_should_you_choose_yes_smile' => 'Why should you choose Yes Smile Center to beautify your teeth?',
    'guarantee' => 'A group of services that guarantee you a 100% successful medical tourism trip.',
    'yes_smile_center' => 'Yes Smile Center',
    'other_centers' => 'Other centers',
];
