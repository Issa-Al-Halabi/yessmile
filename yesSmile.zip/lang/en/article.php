<?php

return [
    'do_you_want_to_have_a_smile' => 'Do You Want To Have A Beautiful Smile??',
    'book_a_free_consultation'  => 'Book a free consultation',
    'more_articles' => 'More Articles',
    'leave_your_comment_here' => 'Leave Your Comment Here',
    'name' => 'Name',
    'email' => 'Email',
    'sending' => 'Sending',
    'add_comment' => 'Add Comment',
    'register_and_receive' => 'Register and receive the treatment plan for free',

];
