<?php

return [
    'privacy_policy' => 'Privacy Policy',
    'no_privacy_policy' => 'There is no privacy policy yet',
    "terms_and_conditions" => "Terms and Conditions",
    "there_are_no_terms_and_conditions_yet" => "There are no terms and conditions yet",
];
