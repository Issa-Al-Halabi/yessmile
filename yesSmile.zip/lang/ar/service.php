<?php

return [
    'consult_our_doctors' => 'استشر أطبائنا مجانًا',
    'results' => "بعض النتائج",
    'yes_for_yessmile' => '<b>يس سمايل</b>… نعم لإبتسامة جميلة.',
];
