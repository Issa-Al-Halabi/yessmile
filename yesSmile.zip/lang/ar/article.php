<?php

return [
    'do_you_want_to_have_a_smile' => 'هل ترغب في تصميم ابتسامة أحلامك؟',
    'book_a_free_consultation' => 'احجز استشارة مجانية',
    'more_articles' => 'المزيد من المقالات',
    'leave_your_comment_here' => 'اترك تعليقك هنا',
    'name' => 'الاسم',
    'email' => 'البريد الالكتروني',
    'sending' => 'يتم الارسال',
    'add_comment' => 'أضف تعليق',
    'register_and_receive' => 'سجل واستلم خطة العلاج مجانا',

];
