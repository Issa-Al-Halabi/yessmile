<?php

return [
    'who_are_we' => 'من نحن',
    'put_a_smile' => 'نحن هنا لإعادة رسم البسمة على وجوهكم',
    'no_title_yet' => 'لا يوجد عنوان بعد',
    'no_description_yet' => 'لا يوجد وصف بعد',
    'consult_our_doctors_for_free' => 'استشر أطبائنا مجانًا',
    'book_your_appointment_now' => 'احجز موعدك الآن',
    'why_should_you_choose_yes_smile' => 'لماذا عليك اختيار مركز يس سمايل لتجميل أسنانك؟',
    'guarantee' => 'مجموعة خدمات تضمن لك رحلة سياحية طبية ناجحة 100%',
    'yes_smile_center' => 'مركز يس سمايل',
    'other_centers' => 'المراكز الأخرى',
];
