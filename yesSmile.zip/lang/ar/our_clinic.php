<?php

return [
    'no_title_yet' => 'لا يوجد عنوان بعد',
    'no_description_yet' => 'لا يوجد وصف بعد',
    'read_more' => 'أقرأ المزيد',
];
