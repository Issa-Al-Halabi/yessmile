<?php

return [

    'Home' => 'الصفحة الرئيسية',
    'ourClinic' => 'عيادتنا',
    'aboutus' => 'من نحن',
    'ourteam' => 'فريقنا',
    'our_world' => 'عالمنا',
    'our_branches' => 'افرعنا',
    'languages' => 'لغات',
    'arabic' => 'العربية',
    'english' => 'الانكليزية',
    'free_consultation' => 'إستشارة مجانية',
    'our_serices' => 'أهم خدماتنا',
    'book_now' => 'احجز الأن',
    'follow_us_on_social_media' => 'تابعنا على السوشال ميديا',
    'contact_us' => 'تواصل معنا',
    'privacy_policy' => 'سياسةالخصوصية',
    'terms' => 'الشروط والأحكام',
    'arabic' => 'العربية',

];
