<?php

return [
    'our_branches' => 'افرعنا',
    'all_our_branches' => 'جميع افرعنا في انحاء العالم',
];
