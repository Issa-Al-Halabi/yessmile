<?php

return [
    'Homea' => 'الصفحة الرئيسية',
];
