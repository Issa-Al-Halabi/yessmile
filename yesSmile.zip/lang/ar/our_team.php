<?php

return [
    'no_title_yet' => 'لا يوجد عنوان بعد',
    'no_description_yet' => 'لا يوجد وصف بعد',
    'our_doctors' => 'أطباؤنا',
    'specialist' => 'أخصائي:',
    'book_a_consultation_with' => 'احجز استشارة مع',
];
