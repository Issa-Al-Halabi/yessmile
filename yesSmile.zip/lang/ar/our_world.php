<?php

return [
    'articles' => 'المقالات',
    'categories' => 'فئات',
    'all' => 'الكل',
    'continue' => 'متابعة',
    'last_news' => 'اخر الأخبار',
];
