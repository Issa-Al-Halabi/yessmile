<?php

return [
    'privacy_policy' => 'سياسة الخصوصية والاستخدام',
    'no_privacy_policy' => 'لا يوجد سياسة الخصوصية بعد',
    "terms_and_conditions" => "الشروط والأحكام",
    "there_are_no_terms_and_conditions_yet" => "لا يوجد الشروط والأحكام بعد",

];
